"""
Content-based movie recommender.

Builds a TF-IDF representation of each movie's genres + overview and
recommends similar movies using cosine similarity.
"""

import os
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "movies.csv")


class MovieRecommender:
    def __init__(self, data_path=DATA_PATH):
        self.data_path = data_path
        self.df = None
        self.similarity_matrix = None
        self.indices = None
        self._load_and_train()

    def _load_and_train(self):
        """Load the dataset and build the TF-IDF similarity matrix."""
        self.df = pd.read_csv(self.data_path)

        # Combine genres + overview into one text field for vectorization
        self.df["combined_features"] = (
            self.df["genres"].fillna("") + " " + self.df["overview"].fillna("")
        )

        tfidf = TfidfVectorizer(stop_words="english")
        tfidf_matrix = tfidf.fit_transform(self.df["combined_features"])

        self.similarity_matrix = cosine_similarity(tfidf_matrix, tfidf_matrix)

        # Map title (lowercased) -> dataframe index for quick lookup
        self.indices = pd.Series(
            self.df.index, index=self.df["title"].str.lower()
        ).drop_duplicates()

    def get_all_titles(self):
        """Return a list of all movie titles in the dataset."""
        return self.df["title"].tolist()

    def recommend(self, title, top_n=5):
        """
        Return a list of recommended movies similar to `title`.

        Each item is a dict with: movieId, title, genres, score
        Raises ValueError if the title is not found.
        """
        key = title.strip().lower()
        if key not in self.indices:
            raise ValueError(f"Movie '{title}' not found in dataset.")

        idx = self.indices[key]

        # Get similarity scores for this movie against all others
        scores = list(enumerate(self.similarity_matrix[idx]))

        # Sort by similarity score, descending, skipping the movie itself
        scores = sorted(scores, key=lambda x: x[1], reverse=True)
        scores = [s for s in scores if s[0] != idx][:top_n]

        results = []
        for movie_idx, score in scores:
            row = self.df.iloc[movie_idx]
            results.append(
                {
                    "movieId": int(row["movieId"]),
                    "title": row["title"],
                    "genres": row["genres"],
                    "score": round(float(score), 4),
                }
            )
        return results

    def search_titles(self, query, limit=10):
        """Return titles that contain the query string (case-insensitive)."""
        query = query.strip().lower()
        matches = self.df[self.df["title"].str.lower().str.contains(query)]
        return matches["title"].head(limit).tolist()


# Singleton instance used by the Flask app
recommender = MovieRecommender()
