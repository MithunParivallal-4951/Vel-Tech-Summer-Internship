# Reel Match — Movie Recommender (Flask)

A simple content-based movie recommender system served via Flask. It builds
a TF-IDF vector for each movie's genres + overview and recommends similar
movies using cosine similarity.

## Project structure

```
movie_recommender/
├── app.py                 # Flask application & API routes
├── requirements.txt       # Python dependencies
├── data/
│   └── movies.csv         # Sample movie dataset (50 movies)
├── model/
│   ├── __init__.py
│   └── recommender.py      # TF-IDF + cosine similarity recommender
└── templates/
    └── index.html          # Simple web UI ("Reel Match")
```

## Setup

1. Create a virtual environment (optional but recommended):
   ```bash
   python -m venv venv
   source venv/bin/activate    # On Windows: venv\Scripts\activate
   ```

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Run the app:
   ```bash
   python app.py
   ```

4. Open your browser at: http://127.0.0.1:5000

## Using your own dataset

Replace `data/movies.csv` with your own data. It must contain at least
these columns:

- `movieId` — unique identifier
- `title` — movie title
- `genres` — space or pipe separated genre tags
- `overview` — short text description / plot summary

The model automatically retrains (re-fits the TF-IDF vectorizer) on
startup using whatever is in `data/movies.csv`.

## API Endpoints

### `GET /api/movies`
Returns all movie titles in the dataset.

```json
{ "movies": ["The Shawshank Redemption", "The Godfather", "..."] }
```

### `GET /api/search?q=<query>`
Search for titles containing the given text (case-insensitive).

```json
{ "results": ["Inception", "Inside Out"] }
```

### `GET /api/recommend?title=<title>&n=<top_n>`
### `POST /api/recommend`  with JSON body `{"title": "...", "top_n": 5}`

Returns the top-N most similar movies.

```json
{
  "title": "Inception",
  "recommendations": [
    {
      "movieId": 7,
      "title": "The Matrix",
      "genres": "Action Sci-Fi",
      "score": 0.3127
    },
    ...
  ]
}
```

If the title isn't found, returns HTTP 404 with an `error` message.

### `GET /api/health`
Simple health check, returns `{"status": "ok"}`.

## Swapping in your own trained model

If you already have a trained recommender (e.g. a collaborative-filtering
model, matrix factorization, or a saved `.pkl` file), replace the contents
of `model/recommender.py`:

1. Load your model/artifacts in `MovieRecommender.__init__`.
2. Implement `recommend(title, top_n)` to return a list of dicts with
   at least `movieId`, `title`, `genres`, and `score` keys (matching the
   shape expected by `app.py` and the front-end).

No other files need to change — `app.py` and `templates/index.html`
work against this interface.

## Deployment notes

- For production, run with a WSGI server, e.g.:
  ```bash
  pip install gunicorn
  gunicorn -w 2 -b 0.0.0.0:8000 app:app
  ```
- Set `debug=False` in `app.py` (or use environment-based config) before
  deploying.
