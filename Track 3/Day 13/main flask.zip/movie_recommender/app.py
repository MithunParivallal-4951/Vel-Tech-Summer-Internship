"""
Flask app exposing a content-based movie recommender.

Endpoints:
    GET  /                -> simple web UI
    GET  /api/movies      -> list all movie titles
    GET  /api/featured    -> a small "Now Showing" grid of movies
    GET  /api/search?q=   -> search movie titles
    GET  /api/recommend?title=<title>&n=<top_n> -> get recommendations
    POST /api/recommend   -> JSON body {"title": "...", "top_n": 5}
    GET  /api/health      -> health check + model status
"""

from flask import Flask, jsonify, request, render_template
from model.recommender import recommender

app = Flask(__name__)


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/api/movies", methods=["GET"])
def list_movies():
    return jsonify({"movies": recommender.get_all_titles()})


@app.route("/api/featured", methods=["GET"])
def featured_movies():
    return jsonify({"featured": recommender.get_featured(n=8)})


@app.route("/api/search", methods=["GET"])
def search_movies():
    query = request.args.get("q", "")
    if not query:
        return jsonify({"error": "Missing query parameter 'q'"}), 400
    return jsonify({"results": recommender.search_titles(query)})


@app.route("/api/recommend", methods=["GET", "POST"])
def recommend():
    if request.method == "POST":
        data = request.get_json(silent=True) or {}
        title = data.get("title", "")
        top_n = data.get("top_n", 5)
    else:
        title = request.args.get("title", "")
        top_n = request.args.get("n", 5)

    if not title:
        return jsonify({"error": "Missing required parameter 'title'"}), 400

    try:
        top_n = int(top_n)
    except (ValueError, TypeError):
        top_n = 5

    try:
        recommendations = recommender.recommend(title, top_n=top_n)
    except ValueError as e:
        return jsonify({"error": str(e)}), 404

    return jsonify({"title": title, "recommendations": recommendations})


@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({
        "status": "ok",
        "model_loaded": True,
        "model_source": recommender.model_source,
        "movie_count": len(recommender.df),
    })


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
