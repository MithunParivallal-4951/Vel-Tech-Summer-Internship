# Film Archive — Movie Database (Flask + SQLite)

A Flask app that loads the 16K Movies dataset into a SQLite database and
serves it through a browsable, searchable "film archive" web interface.

## Project structure

```
movie_db/
├── app.py            # Flask application & routes
├── build_db.py        # Builds movies.db from data/movies.csv
├── movies.db          # SQLite database (generated)
├── requirements.txt
├── data/
│   └── movies.csv     # Source dataset (16,290 rows)
└── templates/
    ├── index.html      # Browsable catalog (search, filter, sort, pagination)
    └── detail.html      # Single movie record page
```

## Setup

1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Build the database (creates `movies.db` from `data/movies.csv`):
   ```bash
   python build_db.py
   ```

3. Run the app:
   ```bash
   python app.py
   ```

4. Open your browser at: http://127.0.0.1:5000

## Features

- **Catalog view** — paginated grid of movie cards (24 per page) showing
  title, release date, runtime, rating, vote count, genres, and director.
- **Search** — filter by title (partial match, case-insensitive).
- **Genre filter** — narrow results to a specific genre.
- **Sorting** — by title, rating (high/low), vote count, or release date
  (newest/oldest).
- **Detail page** — full record for each movie: description, full credits
  (director/writers), genres, rating, votes, and runtime.

## Database schema (`movies` table)

| Column            | Type    | Notes                                  |
|-------------------|---------|----------------------------------------|
| id                | INTEGER | Primary key (1-indexed row number)     |
| title             | TEXT    | Movie title                            |
| release_date      | TEXT    | e.g. "Mar 22, 1996"                    |
| description       | TEXT    | Plot summary                           |
| rating            | REAL    | 0–10, may be NULL                      |
| votes             | INTEGER | Number of ratings, may be NULL         |
| directed_by       | TEXT    | Director(s)                            |
| written_by        | TEXT    | Writer(s)                              |
| duration          | TEXT    | e.g. "1 h 39 m"                        |
| duration_minutes  | INTEGER | Parsed runtime in minutes, may be NULL |
| genres            | TEXT    | Comma-separated genre tags             |

Indexes are created on `title`, `rating`, `votes`, and `release_date` for
fast search/sort.

## API Endpoints

### `GET /api/movies?q=&genre=&sort=&page=&page_size=`
Returns a paginated JSON list of movies.

```json
{
  "movies": [ { "id": 1, "title": "...", "rating": 7.4, ... } ],
  "total": 14693,
  "page": 1,
  "total_pages": 613,
  "page_size": 24
}
```

`sort` accepts: `title`, `rating_desc`, `rating_asc`, `votes_desc`,
`newest`, `oldest`.

### `GET /api/movie/<id>`
Returns full details for a single movie.

### `GET /api/stats`
Returns summary stats: total movie count, average rating, top 5 rated
(with >1000 votes), and the list of available genres.

### `GET /api/health`
Health check — confirms `movies.db` exists and reports the row count.

## Rebuilding the database

If you update `data/movies.csv` (e.g. with a new export), just re-run:

```bash
python build_db.py
```

This drops and recreates `movies.db` from the CSV.

## Deployment notes

- For production, run with a WSGI server, e.g.:
  ```bash
  pip install gunicorn
  gunicorn -w 2 -b 0.0.0.0:8000 app:app
  ```
- Set `debug=False` in `app.py` (or use environment-based config) before
  deploying.
